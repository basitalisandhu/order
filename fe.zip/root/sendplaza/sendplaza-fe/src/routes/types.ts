export interface IPrivateRoute {
  title: string;
  path: string;
  component: string;
  isPrivate: boolean;
}
